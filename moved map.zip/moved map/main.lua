-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
--basic set
display.setStatusBar( display.HiddenStatusBar )

display.setDefault( "anchorX", 0 )
display.setDefault( "anchorY", 0 )

local jelly_m = audio.loadSound("/BGM/g_jelly.mp3")
local coin_m = audio.loadSound("/BGM/g_coin.mp3")
local jump_m = audio.loadSound("/BGM/ch01jump.mp3")

-- Convert Code ( HEX > RGB )
local function CC(hex)
    local r = tonumber(hex:sub(1, 2), 16) / 255
    local g = tonumber(hex:sub(3, 4), 16) / 255
    local b = tonumber(hex:sub(5, 6), 16) / 255
    local a = 255 / 255
    if #hex == 8 then a = tonumber(hex:sub(7, 8), 16) / 255 end
    return r, g, b, a
end
-- var
local _W = display.contentWidth
local _H = display.contentHeight


local map1 = display.newImage ("/map/1.png",0,0)
map1:scale(2.4,2.4)
local map2 = display.newImage ("/map/2.png",0,0)
map2:scale(1.9,1.9)
map2.x = map1.x + map1.width *2.4
local map3 = display.newImage ("/map/3.png",0,0)
map3:scale(1.05,1.05)
map3.x = map2.x + map2.width *1.9
local map4 = display.newImage ("/map/4.png",0,0)
map4:scale(1,1)
map4.x = map3.x + map3.width *1.05
--배경화면들을 움직이기 위해서 이미지를 먼저 불러옵니다.

--jelly
local jelly = display.newImage("/character/gJelly.png")
jelly.x, jelly.y = _W, _H / 2 + 50

local coin = display.newImage("/character/gCoin.png")
coin.x, coin.y = _W, _H / 2 - 10

local s = 3
--function
function movedMap(event)
	map1.x = map1.x - s
	map2.x = map2.x - s
	map3.x = map3.x - s
	map4.x = map4.x - s

	jelly.x = jelly.x - s
	coin.x = coin.x - s

	if jelly.x <= _W / 2 + 25 then
		audio.play(jelly_m)
		jelly.x = _W
	end

	if coin.x <= _W / 2 + 25 then
		audio.play( coin_m )
		coin.x = _W
	end

	if map1.x < -1 * map1.width * 2.4 - _W then
		map1.x = map4.x + map4.width * 1
		if s <= 10 then s = s + 1 end
	end

	if map2.x < -1 * map2.width * 1.9 - _W then
		map2.x = map1.x + map1.width * 2.4
		if s <= 10 then s = s + 1 end
	end

	if map3.x < -1 * map3.width * 1.05 - _W then
		map3.x = map2.x + map2.width * 1.9
		if s <= 10 then s = s + 1 end
	end

	if map4.x < -1 * map4.width * 1.05 - _W then
		map4.x = map3.x + map3.width * 1
		if s <= 10 then s = s + 1 end
	end
end

local bar = display.newRect(0, _H/ 3*2 + 60, _W, 50)
bar:setFillColor(CC("ff6607"))



local cookieData =
{
	width = 100, 
	height = 100,
	numFrames = 7,
	sheetContentWidth = 700,
	sheetContentHeight = 100
}
local sheetData =
{
	{name = "run", frames = {1, 2, 3, 4, 5, 6}, time = 500, loopCount = 0}, 
	{name = "jump", frames = { 7 }, time = 500, loopCount = 0 }
}

local sheet = graphics.newImageSheet("/character/on_cookie.png", cookieData )

local cookieAnimation = display.newSprite( sheet, sheetData)
cookieAnimation.x = _W / 2 - 75
cookieAnimation.y = _H /3 * 2 - 40
cookieAnimation:play()

local alpha = _H / 3 * 2 - 40

local isComplete = 0
local function isCom( event )
	isComplete = 0
	cookieAnimation:setSequence("run")
	cookieAnimation:play()
end
--up
local function jump2(event)
	transition.to(cookieAnimation,
			{time = 275, y = alpha, transition = easing.inQuad, onComplete = isCom})
	end
	--down
	local function jump1(event) 
	if isComplete == 0 then
		cookieAnimation:setSequence("jump")
		cookieAnimation:play()
		audio.play(jump_m)
		isComplete = 1
		transition.to(cookieAnimation,
			{time = 300, y = alpha - 90, transition = easing.outQuad, onComplete = jump2})
	end
end
	
	local jelly_m = audio.loadSound("/BGM/g_jelly.mp3")
	local coin_m = audio.loadSound("/BGM/g_coin.mp3")
	local jump_m = audio.loadSound("/BGM/ch01jump.mp3")

local function playBGM(e)
	media.playSound("/BGM/bgm_main2.mp3", playBGM)
end

media.playSound("/BGM/bgm_main2.mp3", playBGM)

Runtime:addEventListener("enterFrame", movedMap)
map1:addEventListener("tap", jump1)
map2:addEventListener("tap", jump1)
map3:addEventListener("tap", jump1)
map4:addEventListener("tap", jump1)