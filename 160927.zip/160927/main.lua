-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
display.setDefault("anchorX", 0)
display.setDefault("anchorY", 0)
_W = display.contentWidth
_H = display.contentHeight

local physics = require "physics"

physics.start()
physics.setDrawMode("normal")
physics.setGravity(0, 20)

local img = display.newImage("Icon.png", 50, 50)
physics.addBody(img, "dynamic", {bounce = 1.0})

local w1 = display.newRect(0, 0, _W, 20)
physics.addBody(w1, "static", nil)

local w2 = display.newRect(0, 20, 20, _H)
physics.addBody(w2, "static", nil)

local w3 = display.newRect(0, _H-20, _W, 20)
physics.addBody(w3, "static", nil)

local w4 = display.newRect(_W-20, 20, 20, _H)
physics.addBody(w4, "static", nil)

local button = display.newRect(30,30, 30, 30)

a = true

function hi(event)
	
	
	if a == true then
		physics.pause()
	a = false
	elseif a == false then
		physics.start()
	a = true
end
end
button:addEventListener("tap", hi)